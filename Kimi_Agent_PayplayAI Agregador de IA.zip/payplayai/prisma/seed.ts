import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const openRouterModels = [
  { slug: "inclusionai/ring-2.6-1t:free", name: "Ring 2.6 1T", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 8192, category: "text" as const, description: "Modelo Ring 2.6 com 1 trilhão de parâmetros, otimizado para tarefas gerais de texto.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-01-15" },
  { slug: "baidu/cobuddy:free", name: "Baidu CoBuddy", provider: "OPENROUTER" as const, contextLength: 16000, maxTokens: 4096, category: "text" as const, description: "Modelo conversacional da Baidu para assistência geral.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-02-01" },
  { slug: "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free", name: "Nemotron 3 Nano Omni 30B Reasoning", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 8192, category: "text" as const, description: "Modelo NVIDIA Nemotron com raciocínio avançado para tarefas complexas.", parameters: { temperature: 0.6, top_p: 0.9 }, speciality: ["code", "math", "reasoning"], createdDate: "2024-03-01" },
  { slug: "poolside/laguna-xs.2:free", name: "Poolside Laguna XS 2", provider: "OPENROUTER" as const, contextLength: 64000, maxTokens: 4096, category: "code" as const, description: "Modelo compacto da Poolside especializado em geração de código.", parameters: { temperature: 0.2, top_p: 0.95 }, speciality: ["code"], createdDate: "2024-04-01" },
  { slug: "poolside/laguna-m.1:free", name: "Poolside Laguna M 1", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 8192, category: "code" as const, description: "Modelo médio da Poolside para tarefas de programação avançadas.", parameters: { temperature: 0.2, top_p: 0.95 }, speciality: ["code", "programming"], createdDate: "2024-04-15" },
  { slug: "google/gemma-4-26b-a4b-it:free", name: "Gemma 4 26B A4B IT", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 8192, category: "text" as const, description: "Google Gemma 4 com 26B parâmetros, instrução ajustada.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-05-01" },
  { slug: "google/gemma-4-31b-it:free", name: "Gemma 4 31B IT", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 8192, category: "text" as const, description: "Google Gemma 4 com 31B parâmetros, modelo de instrução.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-05-01" },
  { slug: "arcee-ai/trinity-large-thinking:free", name: "Trinity Large Thinking", provider: "OPENROUTER" as const, contextLength: 64000, maxTokens: 8192, category: "text" as const, description: "Modelo Trinity da Arcee AI com capacidades avançadas de raciocínio.", parameters: { temperature: 0.6, top_p: 0.9 }, speciality: ["reasoning", "math", "code"], createdDate: "2024-05-15" },
  { slug: "nvidia/nemotron-3-super-120b-a12b:free", name: "Nemotron 3 Super 120B", provider: "OPENROUTER" as const, contextLength: 64000, maxTokens: 8192, category: "text" as const, description: "Modelo NVIDIA Nemotron Super com 120B parâmetros para tarefas complexas.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math"], createdDate: "2024-06-01" },
  { slug: "minimax/minimax-m2.5:free", name: "MiniMax M2.5", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Modelo MiniMax M2.5 para geração de texto e conversação.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-06-15" },
  { slug: "liquid/lfm-2.5-1.2b-thinking:free", name: "LFM 2.5 1.2B Thinking", provider: "OPENROUTER" as const, contextLength: 16000, maxTokens: 2048, category: "text" as const, description: "Liquid Foundation Model 2.5 compacto com raciocínio.", parameters: { temperature: 0.6, top_p: 0.9 }, speciality: ["reasoning"], createdDate: "2024-07-01" },
  { slug: "liquid/lfm-2.5-1.2b-instruct:free", name: "LFM 2.5 1.2B Instruct", provider: "OPENROUTER" as const, contextLength: 16000, maxTokens: 2048, category: "text" as const, description: "Liquid Foundation Model 2.5 instrução ajustada.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-07-01" },
  { slug: "nvidia/nemotron-3-nano-30b-a3b:free", name: "Nemotron 3 Nano 30B", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Modelo compacto NVIDIA Nemotron 3 para tarefas eficientes.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-07-15" },
  { slug: "nvidia/nemotron-nano-12b-v2-vl:free", name: "Nemotron Nano 12B V2 VL", provider: "OPENROUTER" as const, contextLength: 16000, maxTokens: 4096, category: "multimodal" as const, description: "NVIDIA Nemotron Nano 12B com capacidades visuais e linguísticas.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["multimodal", "vision"], createdDate: "2024-08-01" },
  { slug: "nvidia/nemotron-nano-9b-v2:free", name: "Nemotron Nano 9B V2", provider: "OPENROUTER" as const, contextLength: 16000, maxTokens: 4096, category: "text" as const, description: "NVIDIA Nemotron Nano 9B V2, modelo eficiente e rápido.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-08-01" },
  { slug: "qwen/qwen3-next-80b-a3b-instruct:free", name: "Qwen3 Next 80B Instruct", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Alibaba Qwen3 Next com 80B parâmetros, instrução ajustada.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math"], createdDate: "2024-08-15" },
  { slug: "openai/gpt-oss-120b:free", name: "GPT-OSS 120B", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 16384, category: "text" as const, description: "Modelo OpenAI GPT-OSS com 120B parâmetros para tarefas avançadas.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math", "reasoning"], createdDate: "2024-09-01" },
  { slug: "openai/gpt-oss-20b:free", name: "GPT-OSS 20B", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Modelo OpenAI GPT-OSS com 20B parâmetros, versão eficiente.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-09-01" },
  { slug: "z-ai/glm-4.5-air:free", name: "GLM 4.5 Air", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Zhipu AI GLM 4.5 Air, modelo leve e eficiente.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-09-15" },
  { slug: "qwen/qwen3-coder:free", name: "Qwen3 Coder", provider: "OPENROUTER" as const, contextLength: 64000, maxTokens: 8192, category: "code" as const, description: "Alibaba Qwen3 Coder, especializado em programação e desenvolvimento de software.", parameters: { temperature: 0.2, top_p: 0.95 }, speciality: ["code", "programming"], createdDate: "2024-10-01" },
  { slug: "cognitivecomputations/dolphin-mistral-24b-venice-edition:free", name: "Dolphin Mistral 24B Venice", provider: "OPENROUTER" as const, contextLength: 32000, maxTokens: 8192, category: "text" as const, description: "Dolphin Mistral 24B Venice Edition, otimizado para conversação.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-10-15" },
  { slug: "meta-llama/llama-3.3-70b-instruct:free", name: "Llama 3.3 70B Instruct", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Meta Llama 3.3 70B, um dos modelos mais capazes open-source para instruções.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math", "reasoning"], createdDate: "2024-12-01" },
  { slug: "meta-llama/llama-3.2-3b-instruct:free", name: "Llama 3.2 3B Instruct", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 4096, category: "text" as const, description: "Meta Llama 3.2 3B, versão compacta e rápida.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-09-15" },
  { slug: "nousresearch/hermes-3-llama-3.1-405b:free", name: "Hermes 3 Llama 3.1 405B", provider: "OPENROUTER" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Nous Research Hermes 3 com base Llama 3.1 405B, modelo massivo open-source.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math", "reasoning"], createdDate: "2024-08-01" },
];

const googleModels = [
  { slug: "gemini-2.5-flash", name: "Gemini 2.5 Flash", provider: "GOOGLE" as const, contextLength: 1000000, maxTokens: 8192, category: "multimodal" as const, description: "Google Gemini 2.5 Flash - Modelo multimodal rápido da Google com suporte a texto, imagem e código.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["multimodal", "code", "chat", "vision"], createdDate: "2024-04-01" },
];

const groqModels = [
  { slug: "allam-2-7b", name: "Allam 2 7B", provider: "GROQ" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Modelo Allam 2 com 7B parâmetros para processamento de linguagem natural em árabe e inglês.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat"], createdDate: "2024-01-01" },
  { slug: "canopylabs/orpheus-arabic-saudi", name: "Orpheus Arabic Saudi", provider: "GROQ" as const, contextLength: 16000, maxTokens: 4096, category: "audio" as const, description: "Modelo Orpheus otimizado para árabe saudita.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["audio", "tts"], createdDate: "2024-03-01" },
  { slug: "canopylabs/orpheus-v1-english", name: "Orpheus V1 English", provider: "GROQ" as const, contextLength: 16000, maxTokens: 4096, category: "audio" as const, description: "Modelo Orpheus V1 para inglês.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["audio", "tts"], createdDate: "2024-03-01" },
  { slug: "groq/compound", name: "Groq Compound", provider: "GROQ" as const, contextLength: 64000, maxTokens: 8192, category: "text" as const, description: "Modelo compound da Groq para tarefas complexas de raciocínio.", parameters: { temperature: 0.6, top_p: 0.9 }, speciality: ["reasoning", "code", "math"], createdDate: "2024-04-01" },
  { slug: "groq/compound-mini", name: "Groq Compound Mini", provider: "GROQ" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Versão compacta do Compound da Groq.", parameters: { temperature: 0.6, top_p: 0.9 }, speciality: ["reasoning", "chat"], createdDate: "2024-04-01" },
  { slug: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant", provider: "GROQ" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Meta Llama 3.1 8B otimizado pela Groq para inferência ultra-rápida.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-07-01" },
  { slug: "llama-3.3-70b-versatile", name: "Llama 3.3 70B Versatile", provider: "GROQ" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "Meta Llama 3.3 70B na Groq Cloud, alta performance para diversas tarefas.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math"], createdDate: "2024-12-01" },
  { slug: "meta-llama/llama-4-scout-17b-16e-instruct", name: "Llama 4 Scout 17B 16E", provider: "GROQ" as const, contextLength: 256000, maxTokens: 8192, category: "text" as const, description: "Meta Llama 4 Scout, modelo avançado com janela de contexto massiva.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "reasoning"], createdDate: "2025-01-01" },
  { slug: "meta-llama/llama-prompt-guard-2-22m", name: "Llama Prompt Guard 2 22M", provider: "GROQ" as const, contextLength: 4096, maxTokens: 1024, category: "text" as const, description: "Modelo de segurança para detecção de prompts maliciosos.", parameters: { temperature: 0.1, top_p: 0.5 }, speciality: ["safety"], createdDate: "2024-05-01" },
  { slug: "meta-llama/llama-prompt-guard-2-86m", name: "Llama Prompt Guard 2 86M", provider: "GROQ" as const, contextLength: 4096, maxTokens: 1024, category: "text" as const, description: "Versão maior do Prompt Guard para maior precisão.", parameters: { temperature: 0.1, top_p: 0.5 }, speciality: ["safety"], createdDate: "2024-05-01" },
  { slug: "openai/gpt-oss-120b", name: "GPT-OSS 120B (Groq)", provider: "GROQ" as const, contextLength: 128000, maxTokens: 16384, category: "text" as const, description: "OpenAI GPT-OSS 120B com aceleração Groq.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code", "math"], createdDate: "2024-09-01" },
  { slug: "openai/gpt-oss-20b", name: "GPT-OSS 20B (Groq)", provider: "GROQ" as const, contextLength: 128000, maxTokens: 8192, category: "text" as const, description: "OpenAI GPT-OSS 20B, versão eficiente na Groq.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-09-01" },
  { slug: "openai/gpt-oss-safeguard-20b", name: "GPT-OSS Safeguard 20B", provider: "GROQ" as const, contextLength: 32000, maxTokens: 4096, category: "text" as const, description: "Versão safeguard do GPT-OSS 20B com filtros de segurança.", parameters: { temperature: 0.5, top_p: 0.8 }, speciality: ["safety", "chat"], createdDate: "2024-09-15" },
  { slug: "qwen/qwen3-32b", name: "Qwen3 32B (Groq)", provider: "GROQ" as const, contextLength: 64000, maxTokens: 8192, category: "text" as const, description: "Alibaba Qwen3 32B com inferência acelerada pela Groq.", parameters: { temperature: 0.7, top_p: 0.9 }, speciality: ["chat", "code"], createdDate: "2024-10-01" },
  { slug: "whisper-large-v3", name: "Whisper Large V3", provider: "GROQ" as const, contextLength: 0, maxTokens: 0, category: "audio" as const, description: "OpenAI Whisper Large V3 para transcrição de áudio com alta precisão.", parameters: { temperature: 0 }, speciality: ["audio", "transcription"], createdDate: "2023-11-01" },
  { slug: "whisper-large-v3-turbo", name: "Whisper Large V3 Turbo", provider: "GROQ" as const, contextLength: 0, maxTokens: 0, category: "audio" as const, description: "Versão turbo do Whisper para transcrição ultra-rápida.", parameters: { temperature: 0 }, speciality: ["audio", "transcription"], createdDate: "2024-01-01" },
];

async function seed() {
  console.log("Seeding database...");

  const allModels = [...openRouterModels, ...googleModels, ...groqModels];

  for (const m of allModels) {
    await prisma.modelMetadata.upsert({
      where: { slug: m.slug },
      update: {
        name: m.name,
        contextLength: m.contextLength,
        maxTokens: m.maxTokens,
        category: m.category,
        description: m.description,
        parameters: m.parameters,
        speciality: m.speciality,
        isFree: true,
        isActive: true,
      },
      create: {
        slug: m.slug,
        name: m.name,
        provider: m.provider,
        contextLength: m.contextLength,
        maxTokens: m.maxTokens,
        promptPrice: 0,
        completionPrice: 0,
        requestPrice: 0,
        imagePrice: 0,
        category: m.category,
        description: m.description,
        parameters: m.parameters,
        speciality: m.speciality,
        createdDate: m.createdDate ? new Date(m.createdDate) : null,
        isFree: true,
        isActive: true,
      },
    });
  }

  console.log(`Seeded ${allModels.length} models`);
  console.log("Done!");
}

seed()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
