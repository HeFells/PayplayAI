import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth-utils";

export async function GET(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const days = parseInt(searchParams.get("days") || "30");

    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const [logs, stats, byModel, daily] = await Promise.all([
      prisma.usageLog.findMany({
        where: { userId: session.user.id, createdAt: { gte: startDate } },
        orderBy: { createdAt: "desc" },
        take: 100,
        include: { model: { select: { name: true } } },
      }),
      prisma.usageLog.aggregate({
        where: { userId: session.user.id },
        _sum: { tokensTotal: true, creditsUsed: true },
        _count: { id: true },
        _avg: { latency: true },
      }),
      prisma.usageLog.groupBy({
        by: ["modelSlug"],
        where: { userId: session.user.id, createdAt: { gte: startDate } },
        _sum: { tokensTotal: true },
        _count: { id: true },
        orderBy: { _sum: { tokensTotal: "desc" } },
        take: 10,
      }),
      prisma.usageLog.groupBy({
        by: ["modelSlug"],
        where: { userId: session.user.id, createdAt: { gte: startDate } },
        _sum: { tokensTotal: true, creditsUsed: true },
        _count: { id: true },
      }),
    ]);

    const modelMeta = await prisma.modelMetadata.findMany({
      where: { slug: { in: byModel.map((b) => b.modelSlug) } },
      select: { slug: true, name: true },
    });

    return NextResponse.json({
      logs,
      stats: {
        totalRequests: stats._count?.id || 0,
        totalTokens: stats._sum?.tokensTotal || 0,
        totalCredits: stats._sum?.creditsUsed || 0,
        avgLatency: Math.round(stats._avg?.latency || 0),
      },
      byModel: byModel.map((b) => ({
        modelSlug: b.modelSlug,
        modelName: modelMeta.find((m) => m.slug === b.modelSlug)?.name || b.modelSlug,
        tokens: b._sum?.tokensTotal || 0,
        requests: b._count?.id || 0,
      })),
      daily: daily.map((d) => ({
        date: d.modelSlug,
        tokens: d._sum?.tokensTotal || 0,
        credits: d._sum?.creditsUsed || 0,
        requests: d._count?.id || 0,
      })),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
