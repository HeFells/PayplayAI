import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth-utils";
import { encrypt, maskKey } from "@/lib/encryption";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const keys = await prisma.userApiKey.findMany({
      where: { userId: session.user.id as string },
      select: { id: true, provider: true, isActive: true, createdAt: true },
    });

    return NextResponse.json({ keys: keys.map((k) => ({ ...k, key: "****" })) });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { provider, apiKey } = await req.json();
    if (!provider || !apiKey) {
      return NextResponse.json({ error: "Provider and API key required" }, { status: 400 });
    }

    const encrypted = await encrypt(apiKey);

    await prisma.userApiKey.upsert({
      where: {
        userId_provider: {
          userId: session.user.id as string,
          provider: provider.toUpperCase() as any,
        },
      },
      update: { encryptedKey: encrypted, isActive: true },
      create: {
        userId: session.user.id,
        provider: provider.toUpperCase(),
        encryptedKey: encrypted,
      },
    });

    return NextResponse.json({ success: true, key: maskKey(apiKey) });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const provider = searchParams.get("provider");
    if (!provider) return NextResponse.json({ error: "Provider required" }, { status: 400 });

    await prisma.userApiKey.updateMany({
      where: { userId: session.user.id as string, provider: provider.toUpperCase() as any },
      data: { isActive: false },
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
