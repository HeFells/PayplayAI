import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth-utils";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q") || "";
    const category = searchParams.get("category");
    const provider = searchParams.get("provider");
    const speciality = searchParams.get("speciality");

    const where: any = { isActive: true };
    if (q) {
      where.OR = [
        { name: { contains: q, mode: "insensitive" } },
        { description: { contains: q, mode: "insensitive" } },
        { slug: { contains: q, mode: "insensitive" } },
      ];
    }
    if (category) where.category = category;
    if (provider) where.provider = provider;
    if (speciality) where.speciality = { has: speciality };

    const models = await prisma.modelMetadata.findMany({
      where,
      orderBy: [{ isFree: "desc" }, { name: "asc" }],
      include: {
        _count: {
          select: {
            usageLogs: true,
          },
        },
      },
    });

    // Get usage stats
    const modelsWithStats = await Promise.all(
      models.map(async (m) => {
        const avgLatency = await prisma.usageLog.aggregate({
          where: { modelSlug: m.slug },
          _avg: { latency: true },
        });
        const totalUsage = await prisma.usageLog.aggregate({
          where: { modelSlug: m.slug },
          _sum: { tokensTotal: true },
        });
        return {
          ...m,
          avgLatency: avgLatency._avg?.latency || 0,
          totalTokens: totalUsage._sum?.tokensTotal || 0,
        };
      })
    );

    return NextResponse.json({ models: modelsWithStats });
  } catch (error: any) {
    console.error("Models API error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
