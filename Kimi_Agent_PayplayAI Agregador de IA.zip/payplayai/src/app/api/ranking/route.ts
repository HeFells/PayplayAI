import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const period = (searchParams.get("period") || "day") as "day" | "month" | "year";

    const now = new Date();
    let startDate: Date;
    switch (period) {
      case "month":
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case "year":
        startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    }

    // Get latest snapshot or calculate from usage logs
    const snapshots = await prisma.rankingSnapshot.findMany({
      where: { period, date: { gte: startDate } },
      orderBy: { date: "desc" },
      distinct: ["modelSlug"],
      include: {
        model: {
          select: {
            slug: true,
            name: true,
            provider: true,
            category: true,
            description: true,
            speciality: true,
            isFree: true,
          },
        },
      },
    });

    if (snapshots.length === 0) {
      // Calculate from usage logs
      const usageAgg = await prisma.usageLog.groupBy({
        by: ["modelSlug"],
        where: { createdAt: { gte: startDate } },
        _sum: { tokensTotal: true },
        _avg: { latency: true },
        _count: { id: true },
      });

      const feedbackAgg = await prisma.feedback.groupBy({
        by: ["modelSlug"],
        where: { createdAt: { gte: startDate } },
        _count: { isLike: true },
      });

      const models = await prisma.modelMetadata.findMany({
        select: {
          slug: true,
          name: true,
          provider: true,
          category: true,
          description: true,
          speciality: true,
          isFree: true,
        },
      });

      const ranked = models
        .map((m) => {
          const usage = usageAgg.find((u) => u.modelSlug === m.slug);
          const feedback = feedbackAgg.find((f) => f.modelSlug === m.slug);
          const totalTokens = usage?._sum?.tokensTotal || 0;
          const usageCount = usage?._count?.id || 0;
          const avgLatency = usage?._avg?.latency || 0;
          const likeCount = feedback?._count?.isLike || 0;
          const trendingScore = totalTokens * 0.5 + usageCount * 10 + likeCount * 50;

          return {
            rank: 0,
            modelSlug: m.slug,
            modelName: m.name,
            provider: m.provider,
            category: m.category,
            description: m.description,
            speciality: m.speciality,
            isFree: m.isFree,
            totalTokens,
            usageCount,
            avgLatency,
            likeCount,
            trendingScore,
          };
        })
        .sort((a, b) => b.trendingScore - a.trendingScore)
        .map((m, i) => ({ ...m, rank: i + 1 }))
        .slice(0, 20);

      return NextResponse.json({ rankings: ranked, updatedAt: now.toISOString() });
    }

    const ranked = snapshots
      .sort((a, b) => b.trendingScore - a.trendingScore)
      .map((s, i) => ({
        rank: i + 1,
        modelSlug: s.modelSlug,
        modelName: s.model.name,
        provider: s.model.provider,
        category: s.model.category,
        description: s.model.description,
        speciality: s.model.speciality,
        isFree: s.model.isFree,
        totalTokens: s.totalTokens,
        usageCount: s.usageCount,
        avgLatency: s.avgLatency,
        likeCount: s.likeCount,
        trendingScore: s.trendingScore,
      }));

    return NextResponse.json({ rankings: ranked, updatedAt: now.toISOString() });
  } catch (error: any) {
    console.error("Ranking API error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
