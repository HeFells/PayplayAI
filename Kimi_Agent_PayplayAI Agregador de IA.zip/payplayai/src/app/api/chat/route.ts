import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth-utils";
import { prisma } from "@/lib/prisma";
import { openRouter, groqClient, googleModel, getProviderForModel, OPENROUTER_FREE_MODELS } from "@/lib/providers";
import { checkAndDeductCredits } from "@/lib/credits";
import { decrypt } from "@/lib/encryption";

export async function POST(req: NextRequest) {
  const startTime = Date.now();
  
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { model, messages, systemPrompt, temperature = 0.7, maxTokens = 4096, topP = 0.9, stream = false } = body;

    if (!model || !messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const modelMeta = await prisma.modelMetadata.findUnique({ where: { slug: model } });
    const isFree = modelMeta?.isFree ?? OPENROUTER_FREE_MODELS.includes(model);

    const inputTokens = JSON.stringify(messages).length / 4;
    const userId = session.user.id as string;
    const creditCheck = await checkAndDeductCredits(userId, Math.ceil(inputTokens), maxTokens, isFree);
    if (!creditCheck.allowed) {
      return NextResponse.json({ error: creditCheck.message || "Credits exhausted" }, { status: 403 });
    }

    let apiKey: string | undefined;
    const provider = getProviderForModel(model);
    const userApiKey = await prisma.userApiKey.findFirst({
      where: { userId, provider: provider.toUpperCase() as any, isActive: true },
    });
    if (userApiKey) {
      apiKey = await decrypt(userApiKey.encryptedKey);
    }

    const providerName = getProviderForModel(model);

    if (stream) {
      const encoder = new TextEncoder();
      const streamOut = new ReadableStream({
        async start(controller) {
          try {
            let fullResponse = "";
            const streamStart = Date.now();

            if (providerName === "google") {
              const chat = googleModel.startChat({
                history: messages.slice(0, -1).map((m: any) => ({
                  role: m.role === "user" ? "user" : "model",
                  parts: [{ text: m.content }],
                })),
                generationConfig: { temperature, maxOutputTokens: maxTokens, topP },
              });
              const result = await chat.sendMessageStream(messages[messages.length - 1]?.content || "");
              for await (const chunk of result.stream) {
                const text = chunk.text();
                fullResponse += text;
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: text })}\n\n`));
              }
            } else if (providerName === "groq") {
              const groq = apiKey ? new (await import("groq-sdk")).default({ apiKey }) : groqClient;
              const response = await groq.chat.completions.create({
                model,
                messages: systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages,
                temperature,
                max_tokens: maxTokens,
                top_p: topP,
                stream: true,
              });
              for await (const chunk of response) {
                const text = chunk.choices[0]?.delta?.content || "";
                fullResponse += text;
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: text })}\n\n`));
              }
            } else {
              const { default: OpenAI } = await import("openai");
              const orClient = apiKey
                ? new OpenAI({
                    baseURL: "https://openrouter.ai/api/v1",
                    apiKey,
                    defaultHeaders: {
                      "HTTP-Referer": process.env.NEXTAUTH_URL || "https://payplayai.com",
                      "X-Title": "PayplayAI",
                    },
                  })
                : openRouter;
              const response = await orClient.chat.completions.create({
                model,
                messages: systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages,
                temperature,
                max_tokens: maxTokens,
                top_p: topP,
                stream: true,
              });
              for await (const chunk of response as any) {
                const text = chunk.choices?.[0]?.delta?.content || "";
                fullResponse += text;
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: text })}\n\n`));
              }
            }

            const latency = Date.now() - streamStart;
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true, latency, tokensOutput: fullResponse.length / 4 })}\n\n`));
            controller.close();

            await prisma.usageLog.create({
              data: {
                userId,
                modelSlug: model,
                tokensInput: Math.ceil(inputTokens),
                tokensOutput: Math.ceil(fullResponse.length / 4),
                tokensTotal: Math.ceil(inputTokens + fullResponse.length / 4),
                latency,
                creditsUsed: creditCheck.creditsUsed,
              },
            });
          } catch (err: any) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: err.message })}\n\n`));
            controller.close();
          }
        },
      });

      return new Response(streamOut, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    }

    // Non-streaming
    let response: any;
    if (providerName === "google") {
      const chat = googleModel.startChat({
        history: messages.slice(0, -1).map((m: any) => ({
          role: m.role === "user" ? "user" : "model",
          parts: [{ text: m.content }],
        })),
        generationConfig: { temperature, maxOutputTokens: maxTokens, topP },
      });
      const result = await chat.sendMessage(messages[messages.length - 1]?.content || "");
      response = { content: result.response.text() };
    } else if (providerName === "groq") {
      const { default: Groq } = await import("groq-sdk");
      const groq = apiKey ? new Groq({ apiKey }) : groqClient;
      const result = await groq.chat.completions.create({
        model,
        messages: systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages,
        temperature,
        max_tokens: maxTokens,
        top_p: topP,
      });
      response = { content: result.choices[0]?.message?.content || "" };
    } else {
      const { default: OpenAI } = await import("openai");
      const orClient = apiKey
        ? new OpenAI({
            baseURL: "https://openrouter.ai/api/v1",
            apiKey,
            defaultHeaders: {
              "HTTP-Referer": process.env.NEXTAUTH_URL || "https://payplayai.com",
              "X-Title": "PayplayAI",
            },
          })
        : openRouter;
      const result = await orClient.chat.completions.create({
        model,
        messages: systemPrompt ? [{ role: "system", content: systemPrompt }, ...messages] : messages,
        temperature,
        max_tokens: maxTokens,
        top_p: topP,
      });
      response = { content: result.choices?.[0]?.message?.content || "" };
    }

    const latency = Date.now() - startTime;
    const outputTokens = Math.ceil((response.content?.length || 0) / 4);

    await prisma.usageLog.create({
      data: {
        userId,
        modelSlug: model,
        tokensInput: Math.ceil(inputTokens),
        tokensOutput: outputTokens,
        tokensTotal: Math.ceil(inputTokens + outputTokens),
        latency,
        creditsUsed: creditCheck.creditsUsed,
      },
    });

    return NextResponse.json({
      content: response.content,
      latency,
      creditsUsed: creditCheck.creditsUsed,
      remainingCredits: creditCheck.remaining,
    });
  } catch (error: any) {
    console.error("Chat error:", error);
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 });
  }
}
