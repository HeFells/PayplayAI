import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth-utils";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const sessions = await prisma.playgroundSession.findMany({
      where: { userId: session.user.id, isArchived: false },
      orderBy: { updatedAt: "desc" },
      include: { model: { select: { name: true } } },
    });

    return NextResponse.json({ sessions });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { modelSlug, systemPrompt, messages, title } = await req.json();

    const saved = await prisma.playgroundSession.create({
      data: {
        userId: session.user.id,
        modelSlug,
        systemPrompt,
        messages: messages || [],
        title: title || "Nova conversa",
      },
    });

    return NextResponse.json({ session: saved });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id, messages, title } = await req.json();

    const updated = await prisma.playgroundSession.updateMany({
      where: { id, userId: session.user.id },
      data: { messages, title, updatedAt: new Date() },
    });

    return NextResponse.json({ updated: updated.count });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    await prisma.playgroundSession.updateMany({
      where: { id, userId: session.user.id },
      data: { isArchived: true },
    });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
