"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";
import {
  Chrome,
  Github,
  Sparkles,
  Bot,
  MessageSquare,
  Shield,
  Zap,
} from "lucide-react";

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState<string | null>(null);

  const handleSignIn = (provider: string) => {
    setIsLoading(provider);
    signIn(provider, { callbackUrl: "/" });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo */}
        <div className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-pp-500 to-pp-700 flex items-center justify-center shadow-lg shadow-pp-500/20">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gradient">PayplayAI</h1>
            <p className="text-sm text-slate-400 mt-1">
              Agregador de Modelos de IA
            </p>
          </div>
        </div>

        {/* Login Card */}
        <div className="p-6 rounded-2xl bg-slate-900/50 border border-white/5 backdrop-blur-sm space-y-4">
          <h2 className="text-lg font-semibold text-center">Bem-vindo de volta</h2>
          <p className="text-sm text-slate-400 text-center">
            Entre para acessar o playground, salvar histórico e gerenciar suas chaves API.
          </p>

          <div className="space-y-2">
            <button
              onClick={() => handleSignIn("google")}
              disabled={!!isLoading}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
            >
              {isLoading === "google" ? (
                <div className="w-5 h-5 border-2 border-pp-400 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Chrome className="w-5 h-5 text-red-400" />
              )}
              Continuar com Google
            </button>

            <button
              onClick={() => handleSignIn("github")}
              disabled={!!isLoading}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
            >
              {isLoading === "github" ? (
                <div className="w-5 h-5 border-2 border-pp-400 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Github className="w-5 h-5" />
              )}
              Continuar com GitHub
            </button>

            <button
              onClick={() => handleSignIn("huggingface")}
              disabled={!!isLoading}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
            >
              {isLoading === "huggingface" ? (
                <div className="w-5 h-5 border-2 border-pp-400 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Bot className="w-5 h-5 text-yellow-400" />
              )}
              Continuar com Hugging Face
            </button>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: MessageSquare, label: "Playground", desc: "Chat com streaming" },
            { icon: Shield, label: "Seguro", desc: "Chaves criptografadas" },
            { icon: Zap, label: "Rápido", desc: "Resposta em tempo real" },
          ].map((f) => (
            <div key={f.label} className="text-center p-3 rounded-xl bg-white/[2%] border border-white/5">
              <f.icon className="w-5 h-5 text-pp-400 mx-auto mb-1.5" />
              <p className="text-xs font-medium">{f.label}</p>
              <p className="text-[10px] text-slate-500">{f.desc}</p>
            </div>
          ))}
        </div>

        <p className="text-xs text-center text-slate-600">
          Ao entrar, você concorda com os termos de uso e política de privacidade do PayplayAI.
        </p>
      </div>
    </div>
  );
}
