"use client";

import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  Bot,
  Trophy,
  MessageSquare,
  Zap,
  Shield,
  Code,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Globe,
  Lock,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function HomePage() {
  const { data: session } = useSession();

  const { data: rankingData } = useQuery({
    queryKey: ["ranking", "day"],
    queryFn: async () => {
      const res = await fetch("/api/ranking?period=day");
      return res.json();
    },
  });

  const { data: modelsData } = useQuery({
    queryKey: ["models-count"],
    queryFn: async () => {
      const res = await fetch("/api/models");
      return res.json();
    },
  });

  const topModels = rankingData?.rankings?.slice(0, 5) || [];
  const totalModels = modelsData?.models?.length || 0;

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-pp-950 via-slate-900 to-slate-950 border border-pp-500/20 p-12">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-pp-500/10 via-transparent to-transparent" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-pp-500/5 rounded-full blur-3xl" />
        <div className="relative">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pp-500/10 border border-pp-500/20 text-pp-400 text-xs font-medium mb-6">
            <Sparkles className="w-3 h-3" />
            Agregador de Modelos de IA
          </div>
          <h1 className="text-5xl font-bold mb-4 leading-tight">
            Acesse os melhores{" "}
            <span className="text-gradient">modelos de IA</span>
            <br />
            em um só lugar
          </h1>
          <p className="text-lg text-slate-400 max-w-2xl mb-8">
            PayplayAI unifica OpenRouter, Google AI e Groq em uma plataforma única.
            Teste modelos gratuitos, compare rankings e construa suas aplicações com inteligência artificial.
          </p>
          <div className="flex gap-4">
            <Link
              href="/playground"
              className="inline-flex items-center gap-2 px-6 py-3 bg-pp-600 hover:bg-pp-500 text-white rounded-xl font-medium transition-all hover:shadow-lg hover:shadow-pp-500/25"
            >
              <MessageSquare className="w-4 h-4" />
              Ir para Playground
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/models"
              className="inline-flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium border border-white/10 transition-all"
            >
              <Bot className="w-4 h-4" />
              Explorar Modelos
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: "Modelos Disponíveis", value: totalModels.toString(), icon: Bot, color: "text-pp-400", bg: "bg-pp-500/10" },
          { label: "Provedores", value: "3", icon: Globe, color: "text-green-400", bg: "bg-green-500/10" },
          { label: "Modelos Gratuitos", value: "40+", icon: Zap, color: "text-amber-400", bg: "bg-amber-500/10" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="p-6 rounded-xl bg-slate-900/50 border border-white/5 backdrop-blur-sm"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <span className="text-sm text-slate-400">{stat.label}</span>
            </div>
            <p className="text-3xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Top 5 Ranking */}
      <section className="rounded-xl bg-slate-900/50 border border-white/5 overflow-hidden">
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-semibold">Top Modelos do Dia</h2>
          </div>
          <Link
            href="/ranking"
            className="text-sm text-pp-400 hover:text-pp-300 flex items-center gap-1 transition-colors"
          >
            Ver completo
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {topModels.length > 0 ? (
          <div className="divide-y divide-white/5">
            {topModels.map((model: any, i: number) => (
              <div
                key={model.modelSlug}
                className="flex items-center gap-4 px-6 py-4 hover:bg-white/[2%] transition-colors"
              >
                <span
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                    i === 0
                      ? "bg-amber-500/20 text-amber-400"
                      : i === 1
                      ? "bg-slate-400/20 text-slate-300"
                      : i === 2
                      ? "bg-orange-600/20 text-orange-400"
                      : "bg-slate-800 text-slate-500"
                  }`}
                >
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{model.modelName}</p>
                  <p className="text-xs text-slate-500">
                    {model.provider} · {model.usageCount} usos
                  </p>
                </div>
                <div className="flex items-center gap-4 text-xs text-slate-400">
                  <span>{model.totalTokens?.toLocaleString()} tokens</span>
                  <Link
                    href={`/playground?model=${model.modelSlug}`}
                    className="px-3 py-1 rounded-lg bg-pp-500/10 text-pp-400 hover:bg-pp-500/20 transition-colors"
                  >
                    Testar
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-slate-500">
            <Trophy className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>Ainda não há dados suficientes para o ranking.</p>
            <p className="text-sm mt-1">Use os modelos no playground para alimentar o ranking!</p>
          </div>
        )}
      </section>

      {/* Features */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            icon: Code,
            title: "Para Programadores",
            description: "Modelos especializados em código com syntax highlighting e streaming em tempo real.",
            color: "text-blue-400",
            bg: "bg-blue-500/10",
          },
          {
            icon: Shield,
            title: "Chaves Seguras",
            description: "Suas chaves API são criptografadas com AES-256-GCM. BYOK ou use as chaves da plataforma.",
            color: "text-green-400",
            bg: "bg-green-500/10",
          },
          {
            icon: Zap,
            title: "Streaming Rápido",
            description: "Respostas em tempo real via Server-Sent Events. Veja o texto ser gerado aos poucos.",
            color: "text-amber-400",
            bg: "bg-amber-500/10",
          },
          {
            icon: Lock,
            title: "Privado",
            description: "Zero dados de conversa são armazenados. Seu histório fica apenas no seu navegador.",
            color: "text-purple-400",
            bg: "bg-purple-500/10",
          },
        ].map((feature) => (
          <div
            key={feature.title}
            className="p-6 rounded-xl bg-slate-900/50 border border-white/5 backdrop-blur-sm hover:border-white/10 transition-colors"
          >
            <div className={`w-10 h-10 rounded-lg ${feature.bg} flex items-center justify-center mb-4`}>
              <feature.icon className={`w-5 h-5 ${feature.color}`} />
            </div>
            <h3 className="font-semibold mb-2">{feature.title}</h3>
            <p className="text-sm text-slate-400 leading-relaxed">{feature.description}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
