"use client";

import { useState, useRef, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { useQuery } from "@tanstack/react-query";
import {
  Send,
  Bot,
  User,
  Loader2,
  Settings2,
  Trash2,
  Copy,
  Check,
  ThumbsUp,
  ThumbsDown,
  Zap,
  Clock,
  MessageSquare,
  ChevronDown,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatLatency } from "@/lib/utils";

interface Message {
  role: "user" | "assistant";
  content: string;
  latency?: number;
  tokensUsed?: number;
}

function PlaygroundContent() {
  const searchParams = useSearchParams();
  const initialModel = searchParams.get("model") || "meta-llama/llama-3.3-70b-instruct:free";
  const { data: session } = useSession();

  const [model, setModel] = useState(initialModel);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [systemPrompt, setSystemPrompt] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(4096);
  const [topP, setTopP] = useState(0.9);
  const [lastMetrics, setLastMetrics] = useState<{ latency: number; credits: number } | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: modelsData } = useQuery({
    queryKey: ["models"],
    queryFn: async () => {
      const res = await fetch("/api/models");
      return res.json();
    },
  });

  const models = modelsData?.models || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const sendMessage = async () => {
    if (!input.trim() || isStreaming) return;

    const userMessage: Message = { role: "user", content: input.trim() };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setIsStreaming(true);
    setLastMetrics(null);

    const startTime = Date.now();

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          systemPrompt: systemPrompt || undefined,
          temperature,
          maxTokens,
          topP,
          stream: true,
        }),
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: "Unknown error" }));
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: `❌ Erro: ${error.error || response.statusText}` },
        ]);
        setIsStreaming(false);
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let assistantContent = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n").filter((line) => line.trim().startsWith("data: "));

          for (const line of lines) {
            const data = line.replace("data: ", "").trim();
            if (data === "[DONE]") continue;
            if (!data) continue;

            try {
              const parsed = JSON.parse(data);
              if (parsed.done) {
                setLastMetrics({ latency: parsed.latency || Date.now() - startTime, credits: parsed.creditsUsed || 0 });
              } else if (parsed.error) {
                assistantContent += `\n[Erro: ${parsed.error}]`;
              } else if (parsed.content) {
                assistantContent += parsed.content;
                setMessages((prev) => {
                  const rest = prev.filter((_, i) => i < prev.length - 1 || prev[prev.length - 1].role !== "assistant");
                  return [...rest, { role: "assistant", content: assistantContent }];
                });
              }
            } catch {
              // Skip non-JSON data
            }
          }
        }
      }

      setMessages((prev) => {
        const rest = prev.filter((_, i) => i < prev.length - 1 || prev[prev.length - 1].role !== "assistant");
        return [...rest, { role: "assistant", content: assistantContent, latency: Date.now() - startTime }];
      });
    } catch (error: any) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `❌ Erro de conexão: ${error.message}` },
      ]);
    } finally {
      setIsStreaming(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const copyMessage = (content: string, index: number) => {
    navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const clearChat = () => {
    setMessages([]);
    setLastMetrics(null);
  };

  const selectedModel = models.find((m: any) => m.slug === model);

  return (
    <div className="flex h-full">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Chat Header */}
        <div className="h-14 flex-shrink-0 flex items-center justify-between px-4 border-b border-white/5 bg-slate-900/30">
          <div className="flex items-center gap-3">
            <div className="relative">
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="appearance-none pr-8 pl-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-pp-500/50 cursor-pointer"
              >
                <optgroup label="OpenRouter">
                  {models.filter((m: any) => m.provider === "OPENROUTER").map((m: any) => (
                    <option key={m.slug} value={m.slug}>{m.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Google AI">
                  {models.filter((m: any) => m.provider === "GOOGLE").map((m: any) => (
                    <option key={m.slug} value={m.slug}>{m.name}</option>
                  ))}
                </optgroup>
                <optgroup label="Groq">
                  {models.filter((m: any) => m.provider === "GROQ").map((m: any) => (
                    <option key={m.slug} value={m.slug}>{m.name}</option>
                  ))}
                </optgroup>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
            {selectedModel?.isFree && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 text-[10px] font-medium border border-green-500/20">
                <Zap className="w-3 h-3" />
                GRÁTIS
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {lastMetrics && (
              <span className="text-xs text-slate-500 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatLatency(lastMetrics.latency)}
              </span>
            )}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={cn(
                "p-2 rounded-lg transition-colors",
                showSettings ? "bg-pp-500/10 text-pp-400" : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <Settings2 className="w-4 h-4" />
            </button>
            <button
              onClick={clearChat}
              className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              title="Limpar conversa"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-thin">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-500">
              <div className="w-16 h-16 rounded-2xl bg-pp-500/10 flex items-center justify-center mb-4">
                <MessageSquare className="w-8 h-8 text-pp-400" />
              </div>
              <p className="text-lg font-medium text-slate-300 mb-1">Playground PayplayAI</p>
              <p className="text-sm max-w-md">
                Escolha um modelo e comece a conversar. Suas mensagens são processadas via proxy seguro — suas chaves API nunca são expostas.
              </p>
            </div>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={cn(
                "flex gap-3 animate-in",
                msg.role === "user" ? "justify-end" : "justify-start"
              )}
            >
              {msg.role === "assistant" && (
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-pp-500/10 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-pp-400" />
                </div>
              )}

              <div className={cn(
                "max-w-[80%] rounded-xl px-4 py-3",
                msg.role === "user"
                  ? "bg-pp-600 text-white"
                  : "bg-slate-800/80 border border-white/5"
              )}>
                <div className="text-sm whitespace-pre-wrap leading-relaxed">{msg.content}</div>

                {msg.role === "assistant" && (
                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => copyMessage(msg.content, i)}
                      className="p-1 rounded hover:bg-white/10 transition-colors text-slate-500 hover:text-slate-300"
                      title="Copiar"
                    >
                      {copiedIndex === i ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                    <button className="p-1 rounded hover:bg-white/10 transition-colors text-slate-500 hover:text-slate-300" title="Útil">
                      <ThumbsUp className="w-3 h-3" />
                    </button>
                    <button className="p-1 rounded hover:bg-white/10 transition-colors text-slate-500 hover:text-slate-300" title="Não útil">
                      <ThumbsDown className="w-3 h-3" />
                    </button>
                    {msg.latency && (
                      <span className="text-[10px] text-slate-600 ml-auto">{formatLatency(msg.latency)}</span>
                    )}
                  </div>
                )}
              </div>

              {msg.role === "user" && (
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center">
                  <User className="w-4 h-4 text-slate-300" />
                </div>
              )}
            </div>
          ))}

          {isStreaming && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex gap-3 animate-in">
              <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-pp-500/10 flex items-center justify-center">
                <Bot className="w-4 h-4 text-pp-400 animate-pulse" />
              </div>
              <div className="bg-slate-800/80 border border-white/5 rounded-xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 rounded-full bg-pp-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 rounded-full bg-pp-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 rounded-full bg-pp-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="flex-shrink-0 p-4 border-t border-white/5">
          <div className="flex gap-3 items-end max-w-4xl mx-auto">
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Digite sua mensagem... (Shift+Enter para nova linha)"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-pp-500/50 resize-none max-h-[200px] scrollbar-thin"
                rows={1}
                disabled={isStreaming}
              />
            </div>
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isStreaming}
              className={cn(
                "flex-shrink-0 p-3 rounded-xl transition-all",
                input.trim() && !isStreaming
                  ? "bg-pp-600 hover:bg-pp-500 text-white shadow-lg shadow-pp-500/20"
                  : "bg-white/5 text-slate-500 cursor-not-allowed"
              )}
            >
              {isStreaming ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </div>
          {!session?.user && (
            <p className="text-center text-xs text-slate-500 mt-2">
              <a href="/login" className="text-pp-400 hover:underline">Faça login</a> para salvar histórico e usar mais créditos.
            </p>
          )}
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="w-80 flex-shrink-0 border-l border-white/5 bg-slate-900/50 p-4 space-y-6 overflow-y-auto scrollbar-thin">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm">Configurações</h3>
            <button onClick={() => setShowSettings(false)} className="p-1 rounded hover:bg-white/10 text-slate-500">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">System Prompt</label>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                placeholder="Você é um assistente útil..."
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-pp-500/50 resize-none h-20"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block flex justify-between">
                <span>Temperature</span>
                <span className="text-pp-400">{temperature}</span>
              </label>
              <input
                type="range"
                min={0}
                max={2}
                step={0.1}
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
                className="w-full accent-pp-500"
              />
              <div className="flex justify-between text-[10px] text-slate-600">
                <span>Preciso</span>
                <span>Criativo</span>
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block flex justify-between">
                <span>Max Tokens</span>
                <span className="text-pp-400">{maxTokens}</span>
              </label>
              <input
                type="range"
                min={256}
                max={16384}
                step={256}
                value={maxTokens}
                onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                className="w-full accent-pp-500"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block flex justify-between">
                <span>Top P</span>
                <span className="text-pp-400">{topP}</span>
              </label>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={topP}
                onChange={(e) => setTopP(parseFloat(e.target.value))}
                className="w-full accent-pp-500"
              />
            </div>

            {selectedModel && (
              <div className="pt-4 border-t border-white/5 space-y-2">
                <h4 className="text-xs font-medium text-slate-300">Informações do Modelo</h4>
                <div className="text-xs text-slate-400 space-y-1">
                  <p>Contexto: {(selectedModel.contextLength / 1000).toFixed(0)}k tokens</p>
                  <p>Max Output: {selectedModel.maxTokens?.toLocaleString()} tokens</p>
                  <p>Categoria: {selectedModel.category}</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedModel.speciality?.map((s: string) => (
                      <span key={s} className="px-1.5 py-0.5 rounded bg-white/5 text-[10px] border border-white/5">{s}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function PlaygroundPage() {
  return (
    <Suspense fallback={<div className="h-full flex items-center justify-center text-slate-500">Carregando playground...</div>}>
      <PlaygroundContent />
    </Suspense>
  );
}
