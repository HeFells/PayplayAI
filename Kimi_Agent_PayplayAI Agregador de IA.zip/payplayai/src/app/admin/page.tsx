"use client";

import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  Activity,
  Users,
  Bot,
  Coins,
  TrendingUp,
} from "lucide-react";
import { formatNumber } from "@/lib/utils";

export default function AdminPage() {
  const { data: session } = useSession();
  const user = session?.user as any;

  if (!user || user.role !== "ADMIN") {
    redirect("/");
  }

  const { data: modelsData } = useQuery({
    queryKey: ["models"],
    queryFn: async () => {
      const res = await fetch("/api/models");
      return res.json();
    },
  });

  const { data: rankingData } = useQuery({
    queryKey: ["ranking", "day"],
    queryFn: async () => {
      const res = await fetch("/api/ranking?period=day");
      return res.json();
    },
  });

  const models = modelsData?.models || [];
  const rankings = rankingData?.rankings || [];

  const stats = [
    { label: "Modelos Totais", value: models.length.toString(), icon: Bot, color: "text-blue-400 bg-blue-500/10" },
    { label: "Provedores", value: "3", icon: Activity, color: "text-green-400 bg-green-500/10" },
    { label: "Gratuitos", value: models.filter((m: any) => m.isFree).length.toString(), icon: Coins, color: "text-amber-400 bg-amber-500/10" },
    { label: "No Ranking", value: rankings.length.toString(), icon: TrendingUp, color: "text-purple-400 bg-purple-500/10" },
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Painel Admin</h1>
        <p className="text-sm text-slate-400">Visão geral da plataforma PayplayAI.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="p-4 rounded-xl bg-slate-900/50 border border-white/5">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-8 h-8 rounded-lg ${s.color} flex items-center justify-center bg-opacity-10`}>
                <s.icon className={`w-4 h-4 ${s.color.split(" ")[0]}`} />
              </div>
              <span className="text-xs text-slate-400">{s.label}</span>
            </div>
            <p className="text-2xl font-bold">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Models Table */}
      <div className="rounded-xl bg-slate-900/50 border border-white/5 overflow-hidden">
        <div className="p-4 border-b border-white/5">
          <h2 className="font-semibold flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-pp-400" />
            Todos os Modelos
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-slate-400 text-xs">
                <th className="text-left p-3">Nome</th>
                <th className="text-left p-3">Slug</th>
                <th className="text-left p-3">Provider</th>
                <th className="text-left p-3">Categoria</th>
                <th className="text-left p-3">Contexto</th>
                <th className="text-left p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {models.map((m: any) => (
                <tr key={m.slug} className="hover:bg-white/[2%] transition-colors">
                  <td className="p-3 font-medium">{m.name}</td>
                  <td className="p-3 text-slate-400 font-mono text-xs">{m.slug}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-xs bg-white/5 text-slate-400 border border-white/5">
                      {m.provider}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">{m.category}</td>
                  <td className="p-3 text-slate-400">{(m.contextLength / 1000).toFixed(0)}k</td>
                  <td className="p-3">
                    {m.isActive ? (
                      <span className="text-green-400 text-xs">● Ativo</span>
                    ) : (
                      <span className="text-slate-500 text-xs">● Inativo</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
