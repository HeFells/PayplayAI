"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Key,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Shield,
  AlertTriangle,
  Check,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const PROVIDER_LABELS: Record<string, { name: string; color: string }> = {
  OPENROUTER: { name: "OpenRouter", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
  GOOGLE: { name: "Google AI", color: "text-green-400 bg-green-500/10 border-green-500/20" },
  GROQ: { name: "Groq", color: "text-orange-400 bg-orange-500/10 border-orange-500/20" },
};

export default function SettingsPage() {
  const { data: session, status } = useSession();
  const queryClient = useQueryClient();
  const [newProvider, setNewProvider] = useState("OPENROUTER");
  const [newKey, setNewKey] = useState("");
  const [showKey, setShowKey] = useState(false);

  if (status === "unauthenticated") redirect("/login");

  const { data: keysData, isLoading } = useQuery({
    queryKey: ["api-keys"],
    queryFn: async () => {
      const res = await fetch("/api/keys");
      return res.json();
    },
  });

  const addKeyMutation = useMutation({
    mutationFn: async ({ provider, apiKey }: { provider: string; apiKey: string }) => {
      const res = await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider, apiKey }),
      });
      if (!res.ok) throw new Error("Failed to add key");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["api-keys"] });
      setNewKey("");
    },
  });

  const deleteKeyMutation = useMutation({
    mutationFn: async (provider: string) => {
      const res = await fetch(`/api/keys?provider=${provider}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete key");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["api-keys"] }),
  });

  const handleAddKey = () => {
    if (!newKey.trim()) return;
    addKeyMutation.mutate({ provider: newProvider, apiKey: newKey.trim() });
  };

  const user = session?.user as any;
  const keys = keysData?.keys || [];

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Configurações</h1>
        <p className="text-sm text-slate-400">Gerencie suas chaves API e preferências.</p>
      </div>

      {/* Plan Info */}
      <div className="p-5 rounded-xl bg-slate-900/50 border border-white/5">
        <h2 className="font-semibold mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-pp-400" />
          Plano Atual
        </h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-lg font-bold text-amber-400">{user?.plan || "FREE"}</p>
            <p className="text-sm text-slate-400">
              {user?.plan === "FREE" && "100 créditos mensais · 10 req/dia"}
              {user?.plan === "PRO" && "10.000 créditos · 100 req/dia"}
              {user?.plan === "ENTERPRISE" && "Ilimitado · Suporte prioritário"}
            </p>
          </div>
          <p className="text-2xl font-bold">{user?.credits || 0} <span className="text-sm font-normal text-slate-500">créditos</span></p>
        </div>
      </div>

      {/* BYOK Section */}
      <div className="p-5 rounded-xl bg-slate-900/50 border border-white/5 space-y-4">
        <h2 className="font-semibold flex items-center gap-2">
          <Key className="w-4 h-4 text-pp-400" />
          Chaves API (BYOK)
        </h2>
        <p className="text-sm text-slate-400">
          Adicione suas próprias chaves API para usar sem limites. Elas são criptografadas com AES-256-GCM.
        </p>

        <div className="flex gap-2">
          <select
            value={newProvider}
            onChange={(e) => setNewProvider(e.target.value)}
            className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-pp-500/50"
          >
            <option value="OPENROUTER">OpenRouter</option>
            <option value="GOOGLE">Google AI</option>
            <option value="GROQ">Groq</option>
          </select>
          <div className="flex-1 relative">
            <input
              type={showKey ? "text" : "password"}
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              placeholder="sk-..."
              className="w-full pl-3 pr-10 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-pp-500/50"
            />
            <button
              onClick={() => setShowKey(!showKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
            >
              {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <button
            onClick={handleAddKey}
            disabled={!newKey.trim() || addKeyMutation.isPending}
            className="px-4 py-2 bg-pp-600 hover:bg-pp-500 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {addKeyMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            Adicionar
          </button>
        </div>

        {addKeyMutation.isSuccess && (
          <div className="flex items-center gap-2 text-sm text-green-400">
            <Check className="w-4 h-4" />
            Chave adicionada com sucesso!
          </div>
        )}

        {addKeyMutation.isError && (
          <div className="flex items-center gap-2 text-sm text-red-400">
            <AlertTriangle className="w-4 h-4" />
            Erro ao adicionar chave.
          </div>
        )}

        {/* Keys List */}
        <div className="space-y-2 mt-4">
          {isLoading ? (
            <div className="text-center py-4 text-slate-500 text-sm">Carregando...</div>
          ) : keys.length === 0 ? (
            <div className="text-center py-6 text-slate-500 text-sm border border-dashed border-white/10 rounded-lg">
              Nenhuma chave BYOK configurada. Use as chaves gratuitas da plataforma ou adicione suas próprias.
            </div>
          ) : (
            keys.map((k: any) => {
              const label = PROVIDER_LABELS[k.provider] || { name: k.provider, color: "" };
              return (
                <div
                  key={k.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/[2%] border border-white/5"
                >
                  <div className="flex items-center gap-3">
                    <span className={cn("px-2 py-0.5 rounded text-xs font-medium border", label.color)}>
                      {label.name}
                    </span>
                    <span className="text-sm text-slate-400 font-mono">****</span>
                    {k.isActive ? (
                      <span className="text-xs text-green-400">Ativa</span>
                    ) : (
                      <span className="text-xs text-slate-500">Inativa</span>
                    )}
                  </div>
                  <button
                    onClick={() => deleteKeyMutation.mutate(k.provider)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
