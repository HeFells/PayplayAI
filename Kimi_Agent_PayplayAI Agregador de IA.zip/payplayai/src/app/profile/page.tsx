"use client";

import { useSession } from "next-auth/react";
import { redirect } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import {
  User,
  Mail,
  Crown,
  Coins,
  Activity,
  Clock,
  BarChart3,
} from "lucide-react";
import { formatNumber } from "@/lib/utils";

export default function ProfilePage() {
  const { data: session, status } = useSession();

  if (status === "unauthenticated") {
    redirect("/login");
  }

  const user = session?.user as any;

  const { data: usageData } = useQuery({
    queryKey: ["usage"],
    queryFn: async () => {
      const res = await fetch("/api/usage?days=30");
      return res.json();
    },
    enabled: !!user?.id,
  });

  const stats = usageData?.stats;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Meu Perfil</h1>

      {/* Profile Card */}
      <div className="p-6 rounded-xl bg-slate-900/50 border border-white/5">
        <div className="flex items-center gap-4">
          {user?.image ? (
            <img src={user.image} alt={user.name} className="w-16 h-16 rounded-full border-2 border-pp-500/30" />
          ) : (
            <div className="w-16 h-16 rounded-full bg-pp-500/10 border-2 border-pp-500/30 flex items-center justify-center">
              <User className="w-8 h-8 text-pp-400" />
            </div>
          )}
          <div>
            <h2 className="text-lg font-semibold">{user?.name || "Usuário"}</h2>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Mail className="w-4 h-4" />
              {user?.email}
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs font-medium border border-amber-500/20">
                <Crown className="w-3 h-3" />
                {user?.plan || "FREE"}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 text-slate-400 text-xs font-medium border border-white/5">
                <Coins className="w-3 h-3" />
                {user?.credits || 0} créditos
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Total de Requisições", value: formatNumber(stats.totalRequests), icon: Activity },
            { label: "Tokens Processados", value: formatNumber(stats.totalTokens), icon: BarChart3 },
            { label: "Créditos Usados", value: formatNumber(stats.totalCredits), icon: Coins },
            { label: "Latência Média", value: `${stats.avgLatency}ms`, icon: Clock },
          ].map((stat) => (
            <div key={stat.label} className="p-4 rounded-xl bg-slate-900/50 border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className="w-4 h-4 text-pp-400" />
                <span className="text-xs text-slate-400">{stat.label}</span>
              </div>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Usage by Model */}
      {usageData?.byModel?.length > 0 && (
        <div className="rounded-xl bg-slate-900/50 border border-white/5 overflow-hidden">
          <div className="p-4 border-b border-white/5">
            <h3 className="font-semibold">Uso por Modelo (30 dias)</h3>
          </div>
          <div className="divide-y divide-white/5">
            {usageData.byModel.map((m: any) => (
              <div key={m.modelSlug} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{m.modelName}</p>
                  <p className="text-xs text-slate-500">{m.requests} requisições</p>
                </div>
                <span className="text-sm text-slate-400">{formatNumber(m.tokens)} tokens</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
