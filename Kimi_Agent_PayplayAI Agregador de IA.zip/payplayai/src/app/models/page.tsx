"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import {
  Search,
  Filter,
  Bot,
  Zap,
  MessageSquare,
  Code,
  Image,
  Music,
  Calculator,
  Puzzle,
  X,
} from "lucide-react";
import { getProviderColor, getProviderIcon } from "@/lib/utils";
import { cn } from "@/lib/utils";

const categories = [
  { value: "", label: "Todos", icon: Bot },
  { value: "text", label: "Texto", icon: MessageSquare },
  { value: "code", label: "Código", icon: Code },
  { value: "multimodal", label: "Multimodal", icon: Puzzle },
  { value: "audio", label: "Áudio", icon: Music },
  { value: "image", label: "Imagem", icon: Image },
  { value: "math", label: "Matemática", icon: Calculator },
];

const providers = [
  { value: "", label: "Todos" },
  { value: "OPENROUTER", label: "OpenRouter" },
  { value: "GOOGLE", label: "Google AI" },
  { value: "GROQ", label: "Groq" },
];

function ModelsContent() {
  const searchParams = useSearchParams();
  const initialQ = searchParams.get("q") || "";

  const [q, setQ] = useState(initialQ);
  const [category, setCategory] = useState("");
  const [provider, setProvider] = useState("");
  const [speciality, setSpeciality] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["models", q, category, provider, speciality],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (q) params.set("q", q);
      if (category) params.set("category", category);
      if (provider) params.set("provider", provider);
      if (speciality) params.set("speciality", speciality);
      const res = await fetch(`/api/models?${params}`);
      return res.json();
    },
  });

  const models = data?.models || [];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Modelos de IA</h1>
        <p className="text-slate-400">Explore todos os modelos disponíveis nos provedores integrados.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Buscar modelos..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-pp-500/50 transition-all"
          />
          {q && (
            <button onClick={() => setQ("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <select
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
          className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-pp-500/50"
        >
          {providers.map((p) => (
            <option key={p.value} value={p.value}>{p.label}</option>
          ))}
        </select>

        <div className="flex gap-1 flex-wrap">
          {categories.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value === category ? "" : c.value)}
              className={cn(
                "inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all",
                category === c.value
                  ? "bg-pp-500/20 text-pp-400 border border-pp-500/30"
                  : "bg-white/5 text-slate-400 border border-white/5 hover:bg-white/10"
              )}
            >
              <c.icon className="w-3.5 h-3.5" />
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Models Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-48 rounded-xl bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {models.map((model: any) => (
            <div
              key={model.slug}
              className="group p-5 rounded-xl bg-slate-900/50 border border-white/5 hover:border-pp-500/30 hover:bg-slate-900/80 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getProviderIcon(model.provider)}</span>
                  <h3 className="font-semibold text-sm group-hover:text-pp-400 transition-colors">
                    {model.name}
                  </h3>
                </div>
                {model.isFree && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 text-[10px] font-medium border border-green-500/20">
                    <Zap className="w-3 h-3" />
                    GRÁTIS
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-400 mb-3 line-clamp-2">{model.description}</p>

              <div className="flex flex-wrap gap-1.5 mb-3">
                <span className={cn("px-2 py-0.5 rounded-md text-[10px] font-medium border", getProviderColor(model.provider))}>
                  {model.provider}
                </span>
                {model.speciality?.slice(0, 3).map((s: string) => (
                  <span key={s} className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-white/5 text-slate-400 border border-white/5">
                    {s}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-white/5">
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span>Ctx: {(model.contextLength / 1000).toFixed(0)}k</span>
                  <span>Max: {model.maxTokens?.toLocaleString()}</span>
                  {model.avgLatency > 0 && <span>{Math.round(model.avgLatency)}ms</span>}
                </div>
                <Link
                  href={`/playground?model=${model.slug}`}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-pp-500/10 text-pp-400 text-xs font-medium hover:bg-pp-500/20 transition-colors"
                >
                  <Code className="w-3 h-3" />
                  Testar
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {!isLoading && models.length === 0 && (
        <div className="text-center py-20 text-slate-500">
          <Bot className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p className="text-lg">Nenhum modelo encontrado</p>
          <p className="text-sm mt-1">Tente ajustar seus filtros de busca.</p>
        </div>
      )}
    </div>
  );
}

export default function ModelsPage() {
  return (
    <Suspense fallback={<div className="p-6 text-center text-slate-500">Carregando...</div>}>
      <ModelsContent />
    </Suspense>
  );
}
