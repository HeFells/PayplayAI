import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: "PayplayAI - Agregador de Modelos de IA",
  description: "Acesse modelos de IA gratuitos dos melhores provedores em uma única plataforma. OpenRouter, Google AI, Groq e mais.",
  keywords: "IA, modelos, OpenRouter, Google AI, Groq, playground, ranking, LLM",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans min-h-screen bg-slate-950 text-white`}>
        <Providers>
          <div className="flex h-screen overflow-hidden">
            <Sidebar />
            <div className="flex flex-col flex-1 overflow-hidden">
              <Topbar />
              <main className="flex-1 overflow-y-auto scrollbar-thin">
                {children}
              </main>
            </div>
          </div>
        </Providers>
      </body>
    </html>
  );
}
