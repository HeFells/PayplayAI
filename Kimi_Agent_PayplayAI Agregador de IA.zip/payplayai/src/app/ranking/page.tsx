"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import {
  Trophy,
  TrendingUp,
  Clock,
  Zap,
  Code,
  ArrowUpRight,
  Activity,
  Calendar,
} from "lucide-react";
import { formatNumber, formatLatency, getProviderColor, getProviderIcon } from "@/lib/utils";
import { cn } from "@/lib/utils";

const periods = [
  { value: "day", label: "24 Horas", icon: Clock },
  { value: "month", label: "30 Dias", icon: Calendar },
  { value: "year", label: "365 Dias", icon: Activity },
];

export default function RankingPage() {
  const [period, setPeriod] = useState("day");

  const { data, isLoading } = useQuery({
    queryKey: ["ranking", period],
    queryFn: async () => {
      const res = await fetch(`/api/ranking?period=${period}`);
      return res.json();
    },
  });

  const rankings = data?.rankings || [];
  const updatedAt = data?.updatedAt ? new Date(data.updatedAt).toLocaleString("pt-BR") : "";

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            Ranking de Modelos
          </h1>
          <p className="text-sm text-slate-400">
            Modelos mais utilizados para programação e desenvolvimento.
            {updatedAt && <span className="ml-2">Atualizado em {updatedAt}</span>}
          </p>
        </div>
      </div>

      {/* Period Tabs */}
      <div className="flex gap-2 p-1 rounded-xl bg-white/5 border border-white/5 w-fit">
        {periods.map((p) => (
          <button
            key={p.value}
            onClick={() => setPeriod(p.value)}
            className={cn(
              "inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
              period === p.value
                ? "bg-pp-500/20 text-pp-400 border border-pp-500/30"
                : "text-slate-400 hover:text-white hover:bg-white/5"
            )}
          >
            <p.icon className="w-4 h-4" />
            {p.label}
          </button>
        ))}
      </div>

      {/* Rankings Table */}
      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-16 rounded-xl bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {rankings.map((model: any, i: number) => (
            <div
              key={model.modelSlug}
              className="group flex items-center gap-4 p-4 rounded-xl bg-slate-900/50 border border-white/5 hover:border-white/10 hover:bg-slate-900/80 transition-all"
            >
              {/* Rank */}
              <div className="flex-shrink-0 w-10 text-center">
                {i < 3 ? (
                  <div
                    className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold",
                      i === 0
                        ? "bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-lg shadow-amber-500/20"
                        : i === 1
                        ? "bg-gradient-to-br from-slate-300 to-slate-500 text-white shadow-lg shadow-slate-500/20"
                        : "bg-gradient-to-br from-orange-400 to-orange-600 text-white shadow-lg shadow-orange-500/20"
                    )}
                  >
                    {i + 1}
                  </div>
                ) : (
                  <span className="text-xl font-bold text-slate-500">{i + 1}</span>
                )}
              </div>

              {/* Model Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm">{getProviderIcon(model.provider)}</span>
                  <h3 className="font-semibold text-sm">{model.modelName}</h3>
                  <span className={cn("px-2 py-0.5 rounded-md text-[10px] font-medium border", getProviderColor(model.provider))}>
                    {model.provider}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    Score: {Math.round(model.trendingScore).toLocaleString()}
                  </span>
                  <span>{model.usageCount?.toLocaleString()} usos</span>
                  {model.avgLatency > 0 && (
                    <span>{formatLatency(model.avgLatency)} médio</span>
                  )}
                </div>
              </div>

              {/* Sparkline placeholder */}
              <div className="hidden md:flex items-center gap-1">
                {Array.from({ length: 7 }).map((_, j) => {
                  const height = 20 + Math.random() * 30;
                  return (
                    <div
                      key={j}
                      className="w-1.5 rounded-full bg-pp-500/30"
                      style={{ height: `${height}%`, minHeight: 8 }}
                    />
                  );
                })}
              </div>

              {/* Tags */}
              <div className="hidden md:flex gap-1">
                {model.speciality?.slice(0, 2).map((s: string) => (
                  <span key={s} className="px-2 py-0.5 rounded text-[10px] bg-white/5 text-slate-400 border border-white/5">
                    {s}
                  </span>
                ))}
              </div>

              {/* Action */}
              <Link
                href={`/playground?model=${model.modelSlug}`}
                className="flex-shrink-0 inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-pp-500/10 text-pp-400 text-xs font-medium hover:bg-pp-500/20 transition-colors"
              >
                <Code className="w-3 h-3" />
                Testar
                <ArrowUpRight className="w-3 h-3" />
              </Link>
            </div>
          ))}
        </div>
      )}

      {!isLoading && rankings.length === 0 && (
        <div className="text-center py-20 text-slate-500">
          <Trophy className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p className="text-lg">Nenhum dado de ranking disponível</p>
          <p className="text-sm mt-1">Os dados são atualizados diariamente. Volte em breve!</p>
        </div>
      )}
    </div>
  );
}
