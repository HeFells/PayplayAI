"use client";

import { useSession } from "next-auth/react";
import { Search, Coins, Crown, Diamond } from "lucide-react";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function Topbar() {
  const { data: session } = useSession();
  const [search, setSearch] = useState("");
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) router.push(`/models?q=${encodeURIComponent(search.trim())}`);
  };

  const plan = (session?.user as any)?.plan || "FREE";
  const credits = (session?.user as any)?.credits || 0;
  const planColors: Record<string, string> = {
    FREE: "text-slate-400",
    PRO: "text-amber-400",
    ENTERPRISE: "text-purple-400",
  };
  const PlanIcon = plan === "PRO" ? Crown : plan === "ENTERPRISE" ? Diamond : Coins;

  return (
    <header className="h-14 flex-shrink-0 flex items-center justify-between px-6 bg-slate-900/60 backdrop-blur-xl border-b border-white/5">
      <form onSubmit={handleSearch} className="relative w-96">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input
          type="text"
          placeholder="Buscar modelos, provedores..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-pp-500/50 focus:ring-1 focus:ring-pp-500/20 transition-all"
        />
      </form>

      <div className="flex items-center gap-4">
        {session?.user && (
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs font-medium text-slate-300">{credits} créditos</span>
            </div>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 ${planColors[plan]}`}>
              <PlanIcon className="w-3.5 h-3.5" />
              <span className="text-xs font-medium">{plan}</span>
            </div>
          </div>
        )}
        {session?.user?.image ? (
          <img
            src={session.user.image}
            alt={session.user.name || ""}
            className="w-8 h-8 rounded-full border border-white/10"
          />
        ) : session?.user ? (
          <div className="w-8 h-8 rounded-full bg-pp-500/20 border border-pp-500/30 flex items-center justify-center text-xs font-bold text-pp-400">
            {(session.user.name || "U")[0]}
          </div>
        ) : null}
      </div>
    </header>
  );
}
