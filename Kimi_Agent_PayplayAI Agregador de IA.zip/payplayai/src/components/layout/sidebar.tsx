"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import {
  Home,
  Bot,
  Trophy,
  MessageSquare,
  User,
  Settings,
  LogOut,
  LogIn,
  Sparkles,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/models", label: "Modelos", icon: Bot },
  { href: "/ranking", label: "Ranking", icon: Trophy },
  { href: "/playground", label: "Playground", icon: MessageSquare },
];

const bottomItems = [
  { href: "/profile", label: "Perfil", icon: User },
  { href: "/settings", label: "Configurações", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  const { data: session } = useSession();

  return (
    <aside className="w-64 flex-shrink-0 flex flex-col bg-slate-900/80 backdrop-blur-xl border-r border-white/5">
      <div className="p-6">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pp-500 to-pp-700 flex items-center justify-center shadow-lg shadow-pp-500/20 group-hover:shadow-pp-500/40 transition-shadow">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gradient leading-tight">PayplayAI</h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Agregador de IA</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname?.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                isActive
                  ? "bg-pp-500/10 text-pp-400 border border-pp-500/20"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <item.icon className={cn("w-4 h-4", isActive && "text-pp-400")} />
              {item.label}
              {item.href === "/playground" && (
                <Zap className="w-3 h-3 text-amber-400 ml-auto" />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5 space-y-1">
        {session?.user ? (
          <>
            {bottomItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                    isActive
                      ? "bg-pp-500/10 text-pp-400 border border-pp-500/20"
                      : "text-slate-400 hover:text-white hover:bg-white/5"
                  )}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              );
            })}
            <button
              onClick={() => signOut()}
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </>
        ) : (
          <Link
            href="/login"
            className={cn(
              "flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
              pathname === "/login"
                ? "bg-pp-500/10 text-pp-400 border border-pp-500/20"
                : "text-slate-400 hover:text-white hover:bg-white/5"
            )}
          >
            <LogIn className="w-4 h-4" />
            Entrar
          </Link>
        )}
      </div>
    </aside>
  );
}
