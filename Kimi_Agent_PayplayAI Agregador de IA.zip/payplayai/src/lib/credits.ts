import { prisma } from "./prisma";
import { UserPlan } from "@prisma/client";

const PLAN_LIMITS: Record<UserPlan, { dailyRequests: number; maxCredits: number }> = {
  FREE: { dailyRequests: 10, maxCredits: 100 },
  PRO: { dailyRequests: 100, maxCredits: 10000 },
  ENTERPRISE: { dailyRequests: 999999, maxCredits: 999999 },
};

export async function checkAndDeductCredits(
  userId: string,
  tokensInput: number,
  tokensOutput: number,
  isFreeModel: boolean
): Promise<{ allowed: boolean; creditsUsed: number; remaining: number; message?: string }> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return { allowed: false, creditsUsed: 0, remaining: 0, message: "User not found" };

  const limits = PLAN_LIMITS[user.plan];

  // Check daily reset
  const now = new Date();
  const resetTime = user.dailyResetAt;
  if (!resetTime || now.getTime() - resetTime.getTime() > 24 * 60 * 60 * 1000) {
    await prisma.user.update({
      where: { id: userId },
      data: { requestsToday: 0, dailyResetAt: now },
    });
    user.requestsToday = 0;
  }

  if (user.requestsToday >= limits.dailyRequests) {
    return { allowed: false, creditsUsed: 0, remaining: user.credits, message: "Daily request limit reached" };
  }

  // Free models cost 0 credits
  if (isFreeModel) {
    await prisma.user.update({
      where: { id: userId },
      data: { requestsToday: { increment: 1 }, lastRequestAt: now },
    });
    return { allowed: true, creditsUsed: 0, remaining: user.credits };
  }

  // Calculate credits: 1 per 1k input tokens, 2 per 1k output tokens
  const creditsNeeded = Math.ceil(tokensInput / 1000) + Math.ceil((tokensOutput * 2) / 1000);

  if (user.credits < creditsNeeded) {
    return { allowed: false, creditsUsed: 0, remaining: user.credits, message: "Insufficient credits" };
  }

  await prisma.user.update({
    where: { id: userId },
    data: {
      credits: { decrement: creditsNeeded },
      creditsUsed: { increment: creditsNeeded },
      requestsToday: { increment: 1 },
      lastRequestAt: now,
    },
  });

  return { allowed: true, creditsUsed: creditsNeeded, remaining: user.credits - creditsNeeded };
}

export function getPlanLimits(plan: UserPlan) {
  return PLAN_LIMITS[plan];
}
