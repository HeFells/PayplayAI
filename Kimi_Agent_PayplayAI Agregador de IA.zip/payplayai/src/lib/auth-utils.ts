import { authConfig } from "./auth";
import NextAuth from "next-auth";

const { auth } = NextAuth(authConfig);

export { auth };

export async function requireAuth() {
  const session = await auth();
  if (!session?.user?.id) {
    throw new Error("Unauthorized");
  }
  return session;
}
