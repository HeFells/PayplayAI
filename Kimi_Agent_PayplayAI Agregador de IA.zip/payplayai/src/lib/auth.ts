import { NextAuthConfig, Session } from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import Google from "next-auth/providers/google";
import GitHub from "next-auth/providers/github";
import { prisma } from "./prisma";

const huggingfaceProvider = {
  id: "huggingface",
  name: "Hugging Face",
  type: "oauth" as const,
  authorization: {
    url: "https://huggingface.co/oauth/authorize",
    params: { scope: "read-repos write-repos profile" },
  },
  token: "https://huggingface.co/oauth/token",
  userinfo: "https://huggingface.co/api/whoami-v2",
  profile(profile: any) {
    return {
      id: profile.id || profile.sub,
      name: profile.name || profile.fullname || profile.username || "HuggingFace User",
      email: profile.email || `${profile.id}@huggingface.co`,
      image: profile.avatarUrl || null,
    };
  },
  clientId: process.env.HUGGINGFACE_CLIENT_ID || "",
  clientSecret: process.env.HUGGINGFACE_CLIENT_SECRET || "",
  checks: ["state" as const],
};

export const authConfig: NextAuthConfig = {
  adapter: PrismaAdapter(prisma),
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      allowDangerousEmailAccountLinking: true,
    }),
    GitHub({
      clientId: process.env.GITHUB_CLIENT_ID || "",
      clientSecret: process.env.GITHUB_CLIENT_SECRET || "",
      allowDangerousEmailAccountLinking: true,
    }),
    huggingfaceProvider,
  ],
  session: { strategy: "jwt", maxAge: 30 * 24 * 60 * 60 },
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) {
        token.id = user.id;
        token.role = (user as any).role || "USER";
        token.plan = (user as any).plan || "FREE";
        token.credits = (user as any).credits || 100;
      }
      if (account) {
        token.provider = account.provider;
      }
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        (session.user as any).id = token.id as string;
        (session.user as any).role = token.role as string;
        (session.user as any).plan = token.plan as string;
        (session.user as any).credits = token.credits as number;
      }
      return session;
    },
  },
  pages: {
    signIn: "/login",
    error: "/login",
  },
  trustHost: true,
};
