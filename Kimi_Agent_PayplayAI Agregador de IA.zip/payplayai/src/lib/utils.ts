import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(num: number): string {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
}

export function formatLatency(ms: number): string {
  if (ms < 1000) return `${Math.round(ms)}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

export function getProviderColor(provider: string): string {
  const colors: Record<string, string> = {
    OPENROUTER: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    GOOGLE: "bg-green-500/20 text-green-400 border-green-500/30",
    GROQ: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  };
  return colors[provider] || "bg-slate-500/20 text-slate-400 border-slate-500/30";
}

export function getProviderIcon(provider: string): string {
  const icons: Record<string, string> = {
    OPENROUTER: "🔵",
    GOOGLE: "🟢",
    GROQ: "🟠",
  };
  return icons[provider] || "⚪";
}
