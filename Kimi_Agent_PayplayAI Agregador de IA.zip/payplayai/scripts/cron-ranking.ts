import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function calculateRanking(period: "day" | "month" | "year") {
  const now = new Date();
  let startDate: Date;
  switch (period) {
    case "month": startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000); break;
    case "year": startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000); break;
    default: startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }

  const usageAgg = await prisma.usageLog.groupBy({
    by: ["modelSlug"],
    where: { createdAt: { gte: startDate }, status: "success" },
    _sum: { tokensTotal: true },
    _avg: { latency: true },
    _count: { id: true },
  });

  const feedbackAgg = await prisma.feedback.groupBy({
    by: ["modelSlug"],
    where: { createdAt: { gte: startDate } },
    _count: { isLike: true },
  });

  const models = await prisma.modelMetadata.findMany({
    select: { slug: true },
  });

  const snapshots = models.map((m) => {
    const usage = usageAgg.find((u) => u.modelSlug === m.slug);
    const feedback = feedbackAgg.find((f) => f.modelSlug === m.slug);
    const totalTokens = usage?._sum?.tokensTotal || 0;
    const usageCount = usage?._count?.id || 0;
    const avgLatency = usage?._avg?.latency || 0;
    const likeCount = feedback?._count?.isLike || 0;
    const dislikeCount = 0;
    const avgRating = likeCount > 0 ? 4.0 : 3.0;
    const trendingScore = totalTokens * 0.5 + usageCount * 10 + likeCount * 50;

    return {
      period,
      date: now,
      modelSlug: m.slug,
      usageCount,
      totalTokens,
      avgLatency,
      avgRating,
      likeCount,
      dislikeCount,
      trendingScore,
    };
  });

  // Delete old snapshots and insert new ones
  await prisma.rankingSnapshot.deleteMany({ where: { period } });
  for (const snapshot of snapshots) {
    await prisma.rankingSnapshot.create({ data: snapshot });
  }

  console.log(`Ranking ${period}: ${snapshots.length} models`);
}

async function main() {
  console.log("Calculating rankings...");
  for (const period of ["day", "month", "year"] as const) {
    await calculateRanking(period);
  }
  console.log("Done!");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
